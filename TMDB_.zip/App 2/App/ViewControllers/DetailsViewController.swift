import UIKit
import youtube_ios_player_helper

class DetailsViewController: UIViewController {
    

   var realm = RealmFunc.init()
    
    @IBOutlet weak var detailScrollView: UIScrollView!
    @IBOutlet weak var posterImageViewDetail: UIImageView!
    @IBOutlet weak var titelDetailLabel: UILabel!
    @IBOutlet weak var overviewDetailLabel: UILabel!
    @IBOutlet weak var playerView: YTPlayerView!
    
    var movie: MovieUI = MovieUI()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        var imageURLString = ""
        let posterPath = self.movie.posterPath
        imageURLString = "https://image.tmdb.org/t/p/w500/" + posterPath
        let imageURL = URL(string: imageURLString)
        posterImageViewDetail.sd_setImage(with: imageURL, completed: nil)
        
        self.posterImageViewDetail.sd_setImage(with: imageURL, completed: nil)
        
        self.titelDetailLabel.text = movie.title
        self.overviewDetailLabel.text = movie.overview
        
        let alamofireFunc = AlamofireFunc()
        let id = movie.id
        alamofireFunc.requestVideoDetails(id) { videos in
            guard let key = videos.first?.key else { return }
            self.playerView.load(withVideoId: key)
        }
    }
    
    
    @IBAction func addToListButtonPressed(_ sender: Any) {
        
        
        realm.title = self.movie.title
        realm.popularity = self.movie.popularity
        realm.overview = self.movie.overview
        realm.id = self.movie.id
        realm.backdropPath = self.movie.backdropPath
        realm.mediaType = self.movie.mediaType
        realm.posterPath = self.movie.posterPath
        
      
                realm.realmAdd()
        
        let alert = UIAlertController(title: Constants.ui.movieSavedMessage,
                                      message: nil,
                                      preferredStyle: UIAlertController.Style.alert)
        
        alert.addAction(UIAlertAction(title: Constants.ui.okMessage,
                                      style: UIAlertAction.Style.default,
                                      handler: nil))
        self.present(alert, animated: true, completion: nil)
        
        let when = DispatchTime.now() + 0.5
        DispatchQueue.main.asyncAfter(deadline: when){
            alert.dismiss(animated: true, completion: nil)
        }
    }
}



