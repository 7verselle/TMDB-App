import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var collectionView: UICollectionView!
    @IBOutlet weak var movieOrSerieButton: UINavigationItem!
    
    var moviesList: [Movie] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        let cellNameString = String(describing: TrandingMovieCollectionViewCell.self)
        let cellNib = UINib.init(nibName: "TrandingMovieCollectionViewCell", bundle: nil)
        collectionView.register(cellNib, forCellWithReuseIdentifier: cellNameString)
        
        NetworkManager.shared.requestTrendingMovies(completion: { moviesList in
            print(moviesList)
            self.moviesList = moviesList
            self.collectionView.reloadData()
        })
        
        self.collectionView.register(UINib(nibName: "TrandingMovieCollectionViewCell", bundle: nil), forCellWithReuseIdentifier: "TrandingMovieCollectionViewCell")
        
        title = "Movies list"
    }
}
extension ViewController: UICollectionViewDataSource, UICollectionViewDelegate{
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return moviesList.count
    }
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        if let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "TrandingMovieCollectionViewCell", for: indexPath) as? TrandingMovieCollectionViewCell {
            cell.configureWith(moviesList[indexPath.row])
            return cell
        }
        return UICollectionViewCell()
    }
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        if let detailsViewController = storyboard.instantiateViewController(withIdentifier: "DetailsViewController") as? DetailsViewController {
            let movie = moviesList[indexPath.row]
            let movieUI = MovieUI(title: movie.title ?? "",
                                  popularity: movie.popularity ?? 0,
                                  overview: movie.overview ?? "",
                                  id: movie.id ?? 0,
                                  backdropPath: movie.backdropPath ?? "",
                                  mediaType: movie.mediaType ?? "",
                                  posterPath: movie.posterPath ?? "")
            detailsViewController.movie = movieUI
            navigationController?.pushViewController(detailsViewController, animated: true)
        }
    }
}
