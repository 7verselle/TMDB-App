

import Foundation

struct Movie: Codable {
    let adult : Bool?
    let backdropPath : String?
    let genreIDs : [Int]?
    let original_language : String?
    let originalTitle : String?
    let id : Int?
    let vote_count : Int?
    let video : Bool?
    let vote_average : Double?
    let title : String?
    let overview : String?
    let releaseDate : String?
    let posterPath : String?
    let popularity : Double?
    let mediaType : String?
    
    enum CodingKeys: String, CodingKey {
        
        case adult = "adult"
        case backdropPath = "backdrop_path"
        case genreIDs = "genre_ids"
        case original_language = "original_language"
        case originalTitle = "original_title"
        case id = "id"
        case vote_count = "vote_count"
        case video = "video"
        case vote_average = "vote_average"
        case title = "title"
        case overview = "overview"
        case releaseDate = "release_date"
        case posterPath = "poster_path"
        case popularity = "popularity"
        case mediaType = "media_type"
    }
    
    init(from decoder: Decoder) throws {
        let values = try decoder.container(keyedBy: CodingKeys.self)
        adult = try values.decodeIfPresent(Bool.self, forKey: .adult)
        backdropPath = try values.decodeIfPresent(String.self, forKey: .backdropPath)
        genreIDs = try values.decodeIfPresent([Int].self, forKey: .genreIDs)
        original_language = try values.decodeIfPresent(String.self, forKey: .original_language)
        originalTitle = try values.decodeIfPresent(String.self, forKey: .originalTitle)
        id = try values.decodeIfPresent(Int.self, forKey: .id)
        vote_count = try values.decodeIfPresent(Int.self, forKey: .vote_count)
        video = try values.decodeIfPresent(Bool.self, forKey: .video)
        vote_average = try values.decodeIfPresent(Double.self, forKey: .vote_average)
        title = try values.decodeIfPresent(String.self, forKey: .title)
        overview = try values.decodeIfPresent(String.self, forKey: .overview)
        releaseDate = try values.decodeIfPresent(String.self, forKey: .releaseDate)
        posterPath = try values.decodeIfPresent(String.self, forKey: .posterPath)
        popularity = try values.decodeIfPresent(Double.self, forKey: .popularity)
        mediaType = try values.decodeIfPresent(String.self, forKey: .mediaType)
    }
}
