////
////  DetailTableViewCell.swift
////  App
////
////  Created by Valery on 02.12.2021.
////
//
//import UIKit
//import RealmSwift
//
//class DetailTableViewCell: UITableViewCell {
//    
//    @IBOutlet weak var deleteButton: UIButton!
//    
//    var movies: [MovieRealm] = []
//    // Создаем объект реалм
//    let realm = try? Realm()
//
//    override func awakeFromNib() {
//        super.awakeFromNib()
//        // Initialization code
//    }
//
//    override func setSelected(_ selected: Bool, animated: Bool) {
//        super.setSelected(selected, animated: animated)
//
//        // Configure the view for the selected state
//    }
//    
//}
//
//
//
