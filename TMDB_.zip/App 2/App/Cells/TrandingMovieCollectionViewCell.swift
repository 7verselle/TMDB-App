import UIKit
import SDWebImage

class TrandingMovieCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var containerView: UIView!
    @IBOutlet weak var movieImageView: UIImageView!
    @IBOutlet weak var movieTitelLabel: UILabel!
    
    func configureWith(_ item: Movie){
        
        movieTitelLabel.text = item.title ?? item.overview
        
        var imageURLString = ""
        if let posterPath = item.posterPath{
            imageURLString = "https://image.tmdb.org/t/p/w500/" + posterPath
            let imageURL = URL(string: imageURLString)
            movieImageView.sd_setImage(with: imageURL, completed: nil)
        }
        
        containerView.layer.cornerRadius = 16
        containerView.backgroundColor = .white
    }
}
