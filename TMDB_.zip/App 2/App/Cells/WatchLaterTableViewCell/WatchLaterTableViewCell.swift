import UIKit
class WatchLaterTableViewCell: UITableViewCell {
    
    var movie: MovieRealm = MovieRealm()
    
    func configure(movie: MovieRealm){
        self.movie = movie
    }
    
    @IBAction func deleteButtonFunc(_ sender: Any) {
        
        DataManager().deleteMovies(id: movie.id)
        
    }
}
