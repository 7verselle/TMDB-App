import Foundation
import RealmSwift

struct DataManager {
    
    let realm = try? Realm()
    
    func deleteMovies(id: Int) {
        if let cellToDelete = realm?.objects(MovieRealm.self).filter("id = %@", id).first {
            try! realm?.write {
                realm?.delete(cellToDelete)
            }
        }
    }
}
