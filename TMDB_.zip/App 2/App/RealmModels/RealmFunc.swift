import Foundation
import RealmSwift

struct RealmFunc {
    
    func realmInit(){
        let realm = try? Realm()
    }
    //    let realm = try? Realm()
    
    func getMovies() -> [MovieRealm] {
        
        let realm = try? Realm()
        
        var movies = [MovieRealm]()
        guard let moviesResults = realm?.objects(MovieRealm.self) else { return [] }
        for movie in moviesResults {
            movies.append(movie)
        }
        return movies
    }
    
    var title = ""
    var popularity: Double = 0.0
    var overview = ""
    var id: Int = 0
    var backdropPath = ""
    var mediaType = ""
    var posterPath = ""
    var releaseDate = ""
    
    func realmAdd(){
        
        let realm = try? Realm()
        
        let movieRealm = MovieRealm()
        
        movieRealm.title = title
        movieRealm.popularity = popularity
        movieRealm.overview = overview
        movieRealm.id = id
        movieRealm.backdropPath = backdropPath
        movieRealm.mediaType = mediaType
        movieRealm.posterPath = posterPath
        
        try? realm?.write {
            realm?.add(movieRealm, update: .modified)
        }
    }
    
    
    
}
